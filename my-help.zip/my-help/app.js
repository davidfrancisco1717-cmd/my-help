const $ = (selector) => document.querySelector(selector);

const store = {
  read(key) {
    try { return JSON.parse(localStorage.getItem('myhelp_' + key) || '[]'); }
    catch { return []; }
  },
  write(key, value) {
    localStorage.setItem('myhelp_' + key, JSON.stringify(value));
  }
};

let messages = store.read('messages');
let tickets = store.read('tickets');

const titles = {
  assistant: 'Assistente IA',
  support: 'Suporte humano',
  history: 'Histórico'
};

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function showView(view) {
  document.querySelectorAll('.view').forEach((item) => item.classList.remove('active'));
  $('#' + view + 'View').classList.add('active');
  document.querySelectorAll('.nav-link').forEach((item) => {
    item.classList.toggle('active', item.dataset.view === view);
  });
  $('#pageTitle').textContent = titles[view];
  $('#sidebar').classList.remove('open');
  if (view === 'history') renderHistory();
  if (view === 'support') renderTickets();
}

document.querySelectorAll('.nav-link').forEach((button) => {
  button.addEventListener('click', () => showView(button.dataset.view));
});

$('#menuButton').addEventListener('click', () => {
  $('#sidebar').classList.toggle('open');
});

document.querySelectorAll('[data-prompt]').forEach((button) => {
  button.addEventListener('click', () => {
    $('#chatInput').value = button.dataset.prompt;
    $('#chatInput').focus();
  });
});

function renderMessages() {
  const element = $('#chatMessages');
  element.innerHTML =
    '<div class="message assistant"><span class="message-icon">M</span><div><strong>My Help</strong><p>Olá! Sou o assistente do My Help. Conta-me o que precisas e vou orientar-te.</p></div></div>' +
    messages.map((message) =>
      '<div class="message ' + message.role + '"><span class="message-icon">' +
      (message.role === 'user' ? 'EU' : 'M') + '</span><div><strong>' +
      (message.role === 'user' ? 'Tu' : 'My Help') + '</strong><p>' +
      escapeHtml(message.text) + '</p></div></div>'
    ).join('');
  element.scrollTop = element.scrollHeight;
}

$('#chatForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const text = $('#chatInput').value.trim();
  if (!text) return;
  messages.push({ role: 'user', text, at: Date.now() });
  store.write('messages', messages);
  $('#chatInput').value = '';
  renderMessages();
});

$('#ticketForm').addEventListener('submit', (event) => {
  event.preventDefault();
  tickets.unshift({
    id: Date.now(),
    subject: $('#ticketSubject').value.trim(),
    details: $('#ticketDetails').value.trim(),
    status: 'Novo',
    date: new Date().toLocaleString('pt-PT')
  });
  store.write('tickets', tickets);
  event.target.reset();
  renderTickets();
  alert('Pedido guardado neste dispositivo. O envio para uma equipa de atendimento será ligado numa próxima fase.');
});

function renderTickets() {
  $('#ticketList').innerHTML = tickets.length
    ? tickets.map((ticket) =>
        '<div class="ticket"><strong>' + escapeHtml(ticket.subject) +
        '</strong><small>' + escapeHtml(ticket.date) + '</small><p>' +
        escapeHtml(ticket.details) + '</p><span class="pill">' +
        escapeHtml(ticket.status) + '</span></div>'
      ).join('')
    : '<div class="empty">Ainda não tens pedidos de suporte.</div>';
}

function renderHistory() {
  const items = [
    ...messages.map((message) => ({
      kind: 'Mensagem · ' + (message.role === 'user' ? 'Tu' : 'My Help'),
      text: message.text,
      at: message.at || 0
    })),
    ...tickets.map((ticket) => ({
      kind: 'Pedido de suporte',
      text: ticket.subject,
      at: ticket.id
    }))
  ].sort((a, b) => b.at - a.at);

  $('#historyList').innerHTML = items.length
    ? items.map((item) =>
        '<div class="history-item"><strong>' + escapeHtml(item.kind) +
        '</strong><p>' + escapeHtml(item.text) + '</p><small>' +
        new Date(item.at).toLocaleString('pt-PT') + '</small></div>'
      ).join('')
    : '<div class="empty">O teu histórico aparecerá aqui.</div>';
}

$('#clearHistory').addEventListener('click', () => {
  if (confirm('Queres apagar as mensagens e pedidos guardados neste dispositivo?')) {
    messages = [];
    tickets = [];
    store.write('messages', messages);
    store.write('tickets', tickets);
    renderHistory();
    renderMessages();
    renderTickets();
  }
});

$('#year').textContent = new Date().getFullYear();
renderMessages();
renderTickets();

# My Help — A tua ajuda, a qualquer momento

## O que está incluído
- `index.html`: estrutura das páginas e dos elementos da plataforma.
- `style.css`: identidade visual e adaptação a telemóveis.
- `app.js`: navegação, histórico local, mensagens e criação de pedidos de suporte.

## Como testar no telemóvel
1. Descarrega e extrai `my-help.zip`.
2. Abre a pasta `my-help`.
3. Abre o ficheiro `index.html` no navegador.
4. Experimenta o Assistente IA, Suporte humano e Histórico.

## Importante: estado desta versão
Esta é uma primeira interface funcional, ainda sem servidor.
- As mensagens e os pedidos ficam guardados apenas no armazenamento local do navegador e dispositivo.
- O campo do assistente ainda não chama um modelo de inteligência artificial.
- Os pedidos de suporte ainda não são enviados para uma equipa nem ficam disponíveis num painel de administrador.
- Não existe autenticação nem sincronização entre dispositivos.

## Próxima fase necessária
Para transformar o protótipo num serviço real, será necessário criar um backend com:
1. Registo, início de sessão e recuperação de conta.
2. Base de dados para utilizadores, conversas e pedidos.
3. Ligação segura a um serviço de IA, mantendo as chaves privadas apenas no servidor.
4. Painel de agentes para responder aos pedidos e atualizar estados.
5. Regras de segurança, limites de utilização e cópias de segurança.

Não coloques chaves secretas de serviços de IA dentro de `app.js` ou de outros ficheiros públicos.

# My Help — A tua ajuda, a qualquer momento

Pacote inicial mobile-first em português.

## O que já funciona nesta versão
- Interface adaptada a telemóveis.
- Navegação entre Assistente IA, Suporte humano e Histórico.
- Conversas e pedidos guardados localmente no navegador.
- Formulário de criação de tickets.
- Preparação de autenticação Supabase.
- Esquema SQL inicial com tabelas e políticas RLS.

## O que ainda precisa de configuração/desenvolvimento
- Criar um projeto Supabase exclusivo para My Help.
- Inserir URL e chave pública no `config.js`.
- Executar `supabase/schema.sql` no SQL Editor do Supabase.
- Criar endpoint seguro de IA no servidor e preencher `AI_ENDPOINT`.
- Implementar sincronização de conversas/tickets com Supabase.
- Construir painel de agentes/admin e gestão segura de permissões.
- Implementar armazenamento privado de anexos e pesquisa web com fontes verificadas.

## Configuração Supabase
1. Cria um projeto Supabase chamado `my-help`.
2. Copia Project URL e chave pública `anon`/`publishable`.
3. Coloca os valores em `config.js`.
4. Abre SQL Editor no Supabase e executa `supabase/schema.sql`.

**Nunca coloques a chave `service_role` no navegador nem no GitHub.**
A chave pública só deve ser usada com as políticas RLS corretamente configuradas.

## Executar
Podes publicar estes ficheiros num alojamento estático ou no GitHub Pages. Como `app.js` usa módulos, abre o site através de um servidor HTTP/HTTPS, não diretamente como ficheiro local.

## Estado
Este é um ponto de partida funcional de interface, não uma plataforma de produção concluída. Não apresenta respostas falsas de IA nem finge que os pedidos foram enviados a uma equipa humana.

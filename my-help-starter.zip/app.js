import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cfg = window.MY_HELP_CONFIG || {};
const hasSupabase = Boolean(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY);
const supabase = hasSupabase ? createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
const $ = (id) => document.getElementById(id);
const store = {
  get(key){ try{return JSON.parse(localStorage.getItem("myhelp_"+key)||"[]")}catch{return []} },
  set(key,value){localStorage.setItem("myhelp_"+key,JSON.stringify(value))}
};
let activeView = "assistant";

function switchView(name){
  activeView=name;
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  $(name+"View").classList.add("active");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  if(name==="history") renderHistory();
  if(name==="support") renderTickets();
  document.querySelector(".sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
$("menuToggle").addEventListener("click",()=>document.querySelector(".sidebar").classList.toggle("open"));
$("newChat").addEventListener("click",()=>{ $("messages").innerHTML=""; addMessage("Olá! Sou o My Help. Como posso ajudar-te?", "assistant"); switchView("assistant"); });

function addMessage(text,role){
  const item=document.createElement("div"); item.className="message "+role;
  if(role==="assistant"){const avatar=document.createElement("div");avatar.className="avatar";avatar.textContent="M";item.append(avatar)}
  const bubble=document.createElement("div");bubble.className="bubble";
  const p=document.createElement("p");p.textContent=text;bubble.append(p);item.append(bubble);$("messages").append(item);$("messages").scrollTop=$("messages").scrollHeight;
}
function saveConversation(question,answer){
  const history=store.get("history");history.unshift({question,answer,date:new Date().toISOString()});store.set("history",history.slice(0,100));
}
async function askAssistant(question){
  addMessage(question,"user");
  if(!cfg.AI_ENDPOINT){
    const answer="A ligação ao serviço de inteligência artificial ainda não foi configurada. O My Help já está preparado para receber essa ligação, mas não vou inventar uma resposta. Configura um endpoint seguro no servidor para ativar o assistente.";
    addMessage(answer,"assistant");saveConversation(question,answer);return;
  }
  try{
    const response=await fetch(cfg.AI_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:question})});
    if(!response.ok) throw new Error("Não foi possível obter uma resposta.");
    const data=await response.json();const answer=String(data.answer||data.message||"O serviço não devolveu uma resposta.").slice(0,12000);
    addMessage(answer,"assistant");saveConversation(question,answer);
  }catch(e){addMessage("Não foi possível contactar o assistente neste momento. Tenta novamente mais tarde.","assistant")}
}
$("chatForm").addEventListener("submit",async e=>{e.preventDefault();const q=$("messageInput").value.trim();if(!q)return;$("messageInput").value="";await askAssistant(q)});
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>{$("messageInput").value=b.dataset.prompt;$("messageInput").focus()}));

$("ticketForm").addEventListener("submit",e=>{
  e.preventDefault();const tickets=store.get("tickets");
  tickets.unshift({id:"MH-"+Date.now().toString().slice(-7),subject:$("ticketSubject").value.trim(),category:$("ticketCategory").value,description:$("ticketDescription").value.trim(),status:"Novo",date:new Date().toISOString()});
  store.set("tickets",tickets);e.target.reset();renderTickets();alert("Pedido guardado neste dispositivo.");
});
function renderTickets(){
  const tickets=store.get("tickets");$("ticketList").innerHTML=tickets.length?tickets.map(t=>`<article class="ticket-card"><b>${escapeHtml(t.subject)}</b><p>${escapeHtml(t.description)}</p><small>${escapeHtml(t.id)} · ${escapeHtml(t.category)} · Estado: ${escapeHtml(t.status)}</small></article>`).join(""):'<div class="empty">Ainda não tens pedidos de suporte.</div>';
}
function renderHistory(){
  const history=store.get("history");$("historyList").innerHTML=history.length?history.map(h=>`<article class="history-card"><b>${escapeHtml(h.question)}</b><p>${escapeHtml(h.answer)}</p><small>${new Date(h.date).toLocaleString("pt-PT")}</small></article>`).join(""):'<div class="empty">Ainda não existem conversas guardadas.</div>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

$("authOpen").addEventListener("click",()=>$("authDialog").showModal());
async function auth(mode){
  const email=$("email").value.trim(),password=$("password").value;
  if(!email||password.length<8){$("authMessage").textContent="Introduz um e-mail válido e uma palavra-passe com pelo menos 8 caracteres.";return}
  if(!supabase){$("authMessage").textContent="Ainda falta configurar o URL e a chave pública do Supabase no ficheiro config.js.";return}
  const result=mode==="signup"?await supabase.auth.signUp({email,password}):await supabase.auth.signInWithPassword({email,password});
  $("authMessage").textContent=result.error?result.error.message:(mode==="signup"?"Conta criada. Verifica o teu e-mail se a confirmação estiver ativa.":"Sessão iniciada.");
}
$("signIn").addEventListener("click",()=>auth("signin"));
$("signUp").addEventListener("click",()=>auth("signup"));
renderTickets();
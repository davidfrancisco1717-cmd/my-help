-- My Help: esquema inicial para Supabase
-- Executa no SQL Editor do projeto Supabase dedicado ao My Help.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'user' check (role in ('user','agent','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Nova conversa',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 12000),
  created_at timestamptz not null default now()
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 120),
  category text not null default 'Outro assunto',
  description text not null check (char_length(description) between 3 and 5000),
  status text not null default 'Novo' check (status in ('Novo','Em atendimento','A aguardar resposta','Resolvido')),
  assigned_to uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ticket_replies (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.tickets enable row level security;
alter table public.ticket_replies enable row level security;

-- Utilizadores apenas consultam/alteram o próprio perfil; a atribuição de funções
-- agent/admin deve ser feita manualmente por um administrador de confiança no painel.
create policy "profile read own" on public.profiles for select using (auth.uid() = id);
create policy "profile update own name" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "conversations own" on public.conversations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "messages own" on public.messages for all using (
  auth.uid() = user_id and exists (
    select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid()
  )
) with check (
  auth.uid() = user_id and exists (
    select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid()
  )
);
create policy "tickets own read" on public.tickets for select using (auth.uid() = user_id);
create policy "tickets own create" on public.tickets for insert with check (auth.uid() = user_id);
create policy "tickets own update" on public.tickets for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "ticket replies own read" on public.ticket_replies for select using (
  exists(select 1 from public.tickets t where t.id = ticket_id and t.user_id = auth.uid())
);
create policy "ticket replies own create" on public.ticket_replies for insert with check (
  auth.uid() = author_id and exists(select 1 from public.tickets t where t.id = ticket_id and t.user_id = auth.uid())
);

-- Perfil automático após registo
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
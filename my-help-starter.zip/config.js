// Configuração pública. Nunca coloques aqui service_role nem outras chaves secretas.
window.MY_HELP_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  // Endpoint seguro do teu servidor para IA, quando estiver implementado.
  AI_ENDPOINT: ""
};